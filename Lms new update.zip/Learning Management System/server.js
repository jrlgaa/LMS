require("dotenv").config(); // load .env
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const nodemailer = require("nodemailer");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// ✅ MySQL connection
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) throw err;
  console.log("✅ Connected to MySQL user_db...");
});

// ✅ Nodemailer setup
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS, // App password
  },
});

// ✅ API: Send verification code
app.post("/send-code", (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ success: false, message: "Email is required." });

  const code = Math.floor(100000 + Math.random() * 900000).toString();

  // Save code to DB
  db.query("UPDATE users SET verification_code = ? WHERE email = ?", [code, email], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ success: false, message: "Server error." });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: "Email not found." });
    }

    const mailOptions = {
      from: `"LMS System" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "Your Verification Code",
      text: `Your verification code is: ${code}`,
    };

    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ success: false, message: "Failed to send verification code." });
      }
      console.log(`✅ Verification code ${code} sent to ${email}`);
      res.json({ success: true, message: "Verification code sent!" });
    });
  });
});

// ✅ API: Signup
app.post("/signup", async (req, res) => {
  const { fullName, email, password, role, lrn } = req.body;
  if (!fullName || !email || !password || !role) {
    return res.status(400).json({ success: false, message: "All fields are required." });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    // Check if email exists
    db.query("SELECT * FROM users WHERE email = ?", [email], (err, results) => {
      if (err) return res.status(500).json({ success: false, message: "Server error." });

      if (results.length > 0) {
        if (results[0].verified === 0) {
          return res.status(400).json({ success: false, message: "Email exists but not verified. Check your inbox." });
        } else {
          return res.status(400).json({ success: false, message: "Email already registered." });
        }
      }

      // Insert new user
      db.query(
        "INSERT INTO users (full_name, email, password, role, lrn, verified) VALUES (?, ?, ?, ?, ?, 0)",
        [fullName, email, hashedPassword, role, role === "guardian" ? lrn : null],
        (err2, result2) => {
          if (err2) {
            console.error(err2);
            return res.status(500).json({ success: false, message: "Error creating account." });
          }
          res.json({ success: true, message: "Signup successful! Please verify your email." });
        }
      );
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: "Server error." });
  }
});

// ✅ API: Verify user
app.post("/verify", (req, res) => {
  const { email, code } = req.body;
  if (!email || !code) return res.status(400).json({ success: false, message: "Email and code are required." });

  db.query("SELECT * FROM users WHERE email = ? AND verification_code = ?", [email, code], (err, results) => {
    if (err) return res.status(500).json({ success: false, message: "Server error." });
    if (results.length === 0) return res.status(400).json({ success: false, message: "Invalid code or email." });

    db.query("UPDATE users SET verified = 1, verification_code = NULL WHERE email = ?", [email], (err2) => {
      if (err2) return res.status(500).json({ success: false, message: "Error verifying account." });
      res.json({ success: true, message: "Account verified successfully!" });
    });
  });
});

// ✅ API: Login
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
    if (err) return res.status(500).json({ success: false, message: "Server error." });
    if (results.length === 0) return res.status(401).json({ success: false, message: "Invalid email or password." });

    const user = results[0];
    if (!user.verified) return res.status(403).json({ success: false, message: "Please verify your email first." });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ success: false, message: "Invalid email or password." });

    res.json({ success: true, message: "Login successful!", role: user.role });
  });
});

// ✅ Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));