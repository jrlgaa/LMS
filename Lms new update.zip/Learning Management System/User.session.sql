CREATE USER 'root'@'localhost' IDENTIFIED BY 'lmsaccount123*';
GRANT ALL PRIVILEGES ON user_db.* TO 'root'@'localhost';
FLUSH PRIVILEGES;


USE user_db;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('guardian','teacher') NOT NULL,
  lrn VARCHAR(50),
  verified TINYINT(1) DEFAULT 0,
  verification_code VARCHAR(10) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);