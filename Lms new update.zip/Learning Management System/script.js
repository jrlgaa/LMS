document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("login-form");
  const signupForm = document.getElementById("signup-form");
  const roleSelect = document.getElementById("role-select");
  const verificationCodeInput = document.getElementById("verification-code");
  const lrnInput = document.getElementById("lrn-input");
  const themeToggle = document.getElementById("theme-toggle");
  const backToLoginBtn = document.getElementById("back-to-login");
  const sendCodeBtn = document.getElementById("send-code");

  let generatedCode = null;

  // 🔹 Generate random 5-digit code
  function generateCode() {
    return Math.floor(10000 + Math.random() * 90000).toString();
  }

  // 🔹 Send verification code to backend
  function sendVerificationCode(email) {
    const code = generateCode();
    generatedCode = code; // store globally for validation

    fetch("http://localhost:3000/send-code", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, code }),
    })
      .then((res) => res.text())
      .then((msg) => {
        console.log(msg);
        alert("Verification code sent to " + email);
      })
      .catch((err) => {
        console.error(err);
        alert("Failed to send verification code.");
      });
  }

  // 🔹 Send Code Button
  if (sendCodeBtn) {
    sendCodeBtn.addEventListener("click", () => {
      const email = signupForm?.querySelector('input[type="email"]').value;
      if (!email) {
        alert("Please enter your email before requesting a code.");
        return;
      }
      sendVerificationCode(email);
    });
  }

  // 🔹 Handle Login
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = loginForm.querySelector('input[type="email"]').value;
      const password = loginForm.querySelector('input[type="password"]').value;

      fetch("http://localhost:3000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            localStorage.setItem("userRole", data.role);
            if (data.role === "guardian") {
              window.location.href = "guardian_portal.html";
            } else if (data.role === "teacher") {
              window.location.href = "teacher_portal.html";
            }
          } else {
            alert("Login failed: " + data.message);
          }
        })
        .catch((err) => {
          console.error(err);
          alert("Login request failed.");
        });
    });
  }

  // 🔹 Handle Signup
  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const fullName = signupForm.querySelector('input[type="text"]').value;
      const email = signupForm.querySelector('input[type="email"]').value;
      const role = roleSelect?.value;
      const verificationCode = verificationCodeInput?.value || null;
      const lrn = lrnInput?.value || null;
      const password = signupForm.querySelectorAll('input[type="password"]')[0].value;
      const confirmPassword = signupForm.querySelectorAll('input[type="password"]')[1].value;

      if (!role) {
        alert("Please select a role");
        return;
      }
      if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
      }
      if (!generatedCode) {
        alert("Please request a verification code first.");
        return;
      }
      if (verificationCode !== generatedCode) {
        alert("Invalid verification code. Please try again.");
        return;
      }

      fetch("http://localhost:3000/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email, password, role, lrn }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            localStorage.setItem("userRole", role);
            alert("Signup successful! Please log in.");
            window.location.href = "index.html";
          } else {
            alert("Signup failed: " + data.message);
          }
        })
        .catch((err) => {
          console.error(err);
          alert("Signup request failed.");
        });
    });
  }

  // 🔹 Role selection logic
  if (roleSelect) {
    roleSelect.addEventListener("change", () => {
      if (roleSelect.value === "guardian") {
        lrnInput.classList.remove("hidden");
        lrnInput.setAttribute("required", "true");
      } else {
        lrnInput.classList.add("hidden");
        lrnInput.removeAttribute("required");
      }

      if (roleSelect.value) {
        verificationCodeInput.classList.remove("hidden");
        verificationCodeInput.setAttribute("required", "true");
      } else {
        verificationCodeInput.classList.add("hidden");
        verificationCodeInput.removeAttribute("required");
      }
    });
  }

  // 🔹 Dark/Light mode toggle
  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      document.documentElement.classList.toggle("dark");

      themeToggle.textContent = document.documentElement.classList.contains("dark")
        ? "☀️ Light Mode"
        : "🌙 Dark Mode";

      localStorage.setItem(
        "theme",
        document.documentElement.classList.contains("dark") ? "dark" : "light"
      );
    });

    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "light") {
      document.documentElement.classList.remove("dark");
      themeToggle.textContent = "🌙 Dark Mode";
    }
  }

  // 🔹 Mobile menu toggle
  const menuBtn = document.getElementById("mobile-menu-button");
  const menu = document.getElementById("mobile-menu");
  if (menuBtn && menu) {
    menuBtn.addEventListener("click", () => {
      menu.classList.toggle("hidden");
    });
  }

  // 🔹 Profile dropdown toggle
  const userBtn = document.getElementById("user-menu-button");
  const dropdown = document.getElementById("user-dropdown");
  if (userBtn && dropdown) {
    userBtn.addEventListener("click", () => {
      dropdown.classList.toggle("hidden");
    });
  }

  // 🔹 Back to Login
  if (backToLoginBtn) {
    backToLoginBtn.addEventListener("click", () => {
      window.location.href = "index.html";
    });
  }

  // 🔹 Particles.js config
  if (document.getElementById("particles-js")) {
    particlesJS("particles-js", {
      particles: {
        number: { value: 80, density: { enable: true, value_area: 800 } },
        color: { value: "#3b82f6" },
        shape: { type: "circle" },
        opacity: { value: 0.6, random: true },
        size: { value: 3, random: true },
        line_linked: {
          enable: true,
          distance: 150,
          color: "#3b82f6",
          opacity: 0.4,
          width: 1,
        },
        move: { enable: true, speed: 2, out_mode: "out" },
      },
      interactivity: {
        detect_on: "canvas",
        events: {
          onhover: { enable: true, mode: "repulse" },
          onclick: { enable: true, mode: "push" },
          resize: true,
        },
        modes: {
          repulse: { distance: 100, duration: 0.4 },
          push: { particles_nb: 4 },
        },
      },
      retina_detect: true,
    });
  }
});