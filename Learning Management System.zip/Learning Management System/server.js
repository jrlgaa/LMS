const express = require("express");
const nodemailer = require("nodemailer");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Configure Nodemailer with Gmail + App Password
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "jerielgaa142@gmail.com", 
    pass: "qidr ugmy ckrn nflx",
  },
});

// Route to send verification code
app.post("/send-code", (req, res) => {
  const { email, code } = req.body;

  const mailOptions = {
    from: '"LMS System" <jerielgaa142@gmail.com>',
    to: email,
    subject: "Your Verification Code",
    text: `Hello,\n\nYour verification code is: ${code}\n\nPlease use this to complete your signup.`,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error("❌ Error sending email:", error);
      return res.status(500).send("Error: " + error.message);
    }
    console.log("✅ Email sent:", info.response);
    res.send("Verification code sent successfully!");
  });
});

// Start server
app.listen(3000, () => {
  console.log("🚀 Server running at http://localhost:3000");
});
